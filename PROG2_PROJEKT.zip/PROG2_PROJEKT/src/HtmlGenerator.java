import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;

public class HtmlGenerator
{
    private static String getRootDirectory(File directory)  // a legfelső szülő mappa meghatározásához
    {
        String rootDirectoryName = "images";
        File root = directory;

        while (root != null && !root.getName().equals(rootDirectoryName))
        {
            root = root.getParentFile();
        }

        return root != null ? root.getPath() : "";
    }

    //HTML oldal generálásáért felelős metódus
    public static void generateImagePage(File directory, ImageInfo image, ImageInfo previous, ImageInfo next, List<File> subDirectories)
    {
        String htmlFileName = image.getHtmlFileName();

        try (FileWriter writer = new FileWriter(new File(directory, htmlFileName)))
        {
            writer.write("<!DOCTYPE html>\n<html lang=\"en\">\n<head>\n");
            writer.write("    <meta charset=\"UTF-8\">\n    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\n");
            writer.write("    <title>" + image.getFileName() + "</title>\n");
            writer.write("</head>\n<body>\n");

            String rootDirectoryPath = getRootDirectory(directory);
            writer.write("    <a href=\"" + rootDirectoryPath + "/index.html\">Start page</a><br>\n");

            writer.write("    <div style=\"text-align:center; margin-bottom: 10px;\">\n");
            if (previous != null)
            {
                writer.write("        <a href=\"" + previous.getHtmlFileName() + "\">← Előző</a>\n");
            }
            writer.write("        <span>&nbsp;&nbsp;</span>");
            if (next != null)
            {
                writer.write("        <a href=\"" + next.getHtmlFileName() + "\">Következő →</a>\n");
            }
            writer.write("    </div>\n");

            writer.write("    <h1>" + image.getFileName() + "</h1>\n");
            writer.write("    <a href=\"" + image.getHtmlFileName() + "\">");
            writer.write("        <img src=\"" + image.getFileName() + "\" alt=\"" + image.getFileName() + "\" style=\"max-width:30%; height:auto;\">\n");
            writer.write("    </a>\n");

            writer.write("    <br><a href=\"index.html\">↑ Vissza az indexhez</a>\n");
            writer.write("</body>\n</html>");
        } catch (IOException e)
        {
            System.err.println("Hiba történt a HTML generálása közben: " + e.getMessage());
        }
    }

    //Index oldal generálásáért felelős metódus
    public static void generateIndexPage(File directory, List<ImageInfo> images, List<File> subDirectories)
    {
        try (FileWriter writer = new FileWriter(new File(directory, "index.html")))
        {
            writer.write("<!DOCTYPE html>\n<html lang=\"en\">\n<head>\n");
            writer.write("    <meta charset=\"UTF-8\">\n    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\n");
            writer.write("    <title>" + directory.getName() + " Index</title>\n");
            writer.write("</head>\n<body>\n");

            String rootDirectoryPath = getRootDirectory(directory);
            writer.write("    <a href=\"" + rootDirectoryPath + "/index.html\">Start page</a><br>\n");
            writer.write("    <h1>" + directory.getName() + "</h1>\n");

            for (ImageInfo image : images)
            {
                writer.write("    <a href=\"" + image.getHtmlFileName() + "\">" + image.getFileName() + "</a><br>\n");
            }

            writer.write("    <h2>Directories:</h2>\n");
            for (File subDirectory : subDirectories)
            {
                writer.write("    <a href=\"" + subDirectory.getName() + "/index.html\">" + subDirectory.getName() + "</a><br>\n");
            }
            writer.write("</body>\n</html>");
        } catch (IOException e) {
            System.err.println("Hiba az oldal generalasa kozben: " + e.getMessage());
        }
    }
}