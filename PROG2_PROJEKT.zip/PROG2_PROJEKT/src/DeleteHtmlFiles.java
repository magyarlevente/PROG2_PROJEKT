import java.io.File;

public class DeleteHtmlFiles
{
    public static void main(String[] args)
    {
        String directoryPath = "C:\\Users\\magya\\Desktop\\egyetemi dolgok\\3.félév\\prog2\\Projekt feladat\\Magyar_Levente_JKTFEX_PROG2_PROJEKT\\images";

        File rootDirectory = new File(directoryPath);

        if (rootDirectory.exists() && rootDirectory.isDirectory())
        {
            deleteHtmlFiles(rootDirectory);
        }
    }

    private static void deleteHtmlFiles(File directory)
    {
        File[] files = directory.listFiles();
        if (files != null)
        {
            for (File file : files)
            {
                if (file.isDirectory())
                {
                    deleteHtmlFiles(file);
                } else if (file.isFile() && file.getName().endsWith(".html"))
                {
                    file.delete();
                }
            }
        }
    }
}