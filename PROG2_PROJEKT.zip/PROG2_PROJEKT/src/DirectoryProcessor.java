import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class DirectoryProcessor
{
    private File rootDirectory;

    public DirectoryProcessor(File rootDirectory)
    {
        this.rootDirectory = rootDirectory;
    }

    public void processDirectory()
    {
        processDirectoryRecursive(rootDirectory);
    }

    //mappa,almappa bejárása rekurzívan, majd html generálás
    private void processDirectoryRecursive(File directory)
    {
        List<ImageInfo> images = new ArrayList<>();
        List<File> subDirectories = new ArrayList<>();

        for (File file : directory.listFiles())
        {
            if (file.isDirectory())
            {
                subDirectories.add(file);
            }
            else if (isImageFile(file))
            {
                images.add(new ImageInfo(file));
            }
        }

        HtmlGenerator.generateIndexPage(directory, images, subDirectories);

        for (int i = 0; i < images.size(); i++)
        {
            ImageInfo currentImage = images.get(i);
            ImageInfo previousImage = null;
            if (i > 0)
            {
                previousImage = images.get(i - 1);
            }

            ImageInfo nextImage = null;
            if (i < images.size() - 1)
            {
                nextImage = images.get(i + 1);
            }

            HtmlGenerator.generateImagePage(directory, currentImage, previousImage, nextImage, subDirectories);
        }

        for (File subDirectory : subDirectories)
        {
            processDirectoryRecursive(subDirectory);
        }
    }

    //ez a metódus eldönti, hogy kép fájl-e
    private boolean isImageFile(File file)
    {
        String name = file.getName().toLowerCase();
        return name.endsWith(".jpg") || name.endsWith(".jpeg") || name.endsWith(".png") || name.endsWith(".gif");
    }
}