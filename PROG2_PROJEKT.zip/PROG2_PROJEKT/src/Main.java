import java.io.File;

public class Main
{
    public static void main(String[] args)
    {
        if (args.length != 1)
        {
            System.out.println("Hasznalat: java Main <eleresi ut>");
            return;
        }

        File rootDirectory = new File(args[0]);

        if (!rootDirectory.exists() || !rootDirectory.isDirectory())
        {
            System.out.println("Hibas eleresi ut: " + args[0]);
            return;
        }

        DirectoryProcessor processor = new DirectoryProcessor(rootDirectory);
        processor.processDirectory();
    }
}