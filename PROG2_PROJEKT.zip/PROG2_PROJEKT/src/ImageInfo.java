import java.io.File;

public class ImageInfo
{
    private File file;

    public ImageInfo(File file)
    {
        this.file = file;
    }

    // kép neve
    public String getFileName()
    {
        return file.getName();
    }

    //html fájl neve
    public String getHtmlFileName()
    {
        return file.getName() + ".html";
    }

    //fájl neve
    public File getFile()
    {
        return file;
    }
}